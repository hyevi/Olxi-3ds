// Copyright 2025-2026 Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv2 or any later version
// Refer to the license.txt file included.

namespace AppleUtils {

float GetRefreshRate();
int IsLowPowerModeEnabled();
bool IsRunningFromTerminal();

} // namespace AppleUtils
