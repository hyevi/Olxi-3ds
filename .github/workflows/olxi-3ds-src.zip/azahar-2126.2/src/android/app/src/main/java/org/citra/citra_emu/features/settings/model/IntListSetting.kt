// Copyright 2026 Citra Emulator Project / Azahar Emulator Project
// Licensed under GPLv2 or any later version
// Refer to the license.txt file included.

package org.citra.citra_emu.features.settings.model

import org.citra.citra_emu.features.settings.SettingKeys

enum class IntListSetting(
    override val key: String,
    override val section: String,
    override val defaultValue: List<Int>,
    val canBeEmpty: Boolean = true
) : AbstractListSetting<Int> {

    LAYOUTS_TO_CYCLE(
        SettingKeys.layouts_to_cycle(),
        Settings.SECTION_LAYOUT,
        listOf(0, 1, 2, 3, 4, 5),
        canBeEmpty = false
    ),

    /**
     * Combo Buttons will be given options on MultiChoice setting initialization. This just makes selections empty by default.
     */
    COMBO_BUTTON_BUTTONS(
        SettingKeys.combo_button_buttons(),
        Settings.SECTION_CONTROLS,
        listOf(),
        canBeEmpty = true
    );

    private var backingList: List<Int> = defaultValue
    private var lastValidList: List<Int> = defaultValue

    override var list: List<Int>
        get() = backingList
        set(value) {
            if (!canBeEmpty && value.isEmpty()) {
                backingList = lastValidList
            } else {
                backingList = value
                lastValidList = value
            }
        }

    override val valueAsString: String
        get() = list.joinToString()

    override val isRuntimeEditable: Boolean
        get() {
            for (setting in NOT_RUNTIME_EDITABLE) {
                if (setting == this) {
                    return false
                }
            }
            return true
        }

    companion object {
        private val NOT_RUNTIME_EDITABLE: List<IntListSetting> = emptyList()

        fun from(key: String): IntListSetting? = values().firstOrNull { it.key == key }

        fun clear() = values().forEach { it.list = it.defaultValue }
    }
}
